var files_dup =
[
    [ "Program.java", "_program_8java.html", [
      [ "Program", "class_program.html", "class_program" ]
    ] ],
    [ "Square.java", "_square_8java.html", [
      [ "Square", "class_square.html", "class_square" ]
    ] ],
    [ "Utilities.java", "_utilities_8java.html", [
      [ "Utilities", "class_utilities.html", null ]
    ] ]
];