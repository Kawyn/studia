var hierarchy =
[
    [ "Thread", null, [
      [ "Square", "class_square.html", null ]
    ] ],
    [ "Utilities", "class_utilities.html", null ],
    [ "Application", null, [
      [ "Program", "class_program.html", null ]
    ] ]
];