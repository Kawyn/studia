var class_square =
[
    [ "Square", "class_square.html#ae7704882c68fedb0882afdece4ddcfc2", null ],
    [ "getColor", "class_square.html#a9fb79202af2b2b5c3e41f7055a7f355f", null ],
    [ "getRectangle", "class_square.html#a51647f532d0c1c25f607c1002480b02a", null ],
    [ "getX", "class_square.html#a14455552a354d866fe73d3ed45896fb9", null ],
    [ "getY", "class_square.html#ae780b4c0d703caca98e7eb9c1aa49a5e", null ],
    [ "isActive", "class_square.html#af6c823a9fb643b3ea4c6827251b8b95c", null ],
    [ "run", "class_square.html#aa8de69980f46aeeb28db3fcef553633d", null ],
    [ "setColor", "class_square.html#a4ed244d7719da83ab8bc243ac69eff31", null ]
];