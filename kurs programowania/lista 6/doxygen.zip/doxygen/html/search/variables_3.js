var searchData=
[
  ['size_5fx_0',['SIZE_X',['../class_program.html#a3c448d238708365c155457b335da3430',1,'Program']]],
  ['size_5fy_1',['SIZE_Y',['../class_program.html#ae62ccd6500ceb63c71d9e883e860380b',1,'Program']]],
  ['square_5fsize_2',['SQUARE_SIZE',['../class_program.html#a11012c7c9bf5c0b8793d352e36fea8d1',1,'Program']]],
  ['squares_3',['squares',['../class_program.html#a9d1e4ea1336e8efa1319425cfdc6aedd',1,'Program']]]
];
