var searchData=
[
  ['getcolor_0',['getColor',['../class_square.html#a9fb79202af2b2b5c3e41f7055a7f355f',1,'Square']]],
  ['getrectangle_1',['getRectangle',['../class_square.html#a51647f532d0c1c25f607c1002480b02a',1,'Square']]],
  ['getx_2',['getX',['../class_square.html#a14455552a354d866fe73d3ed45896fb9',1,'Square']]],
  ['gety_3',['getY',['../class_square.html#ae780b4c0d703caca98e7eb9c1aa49a5e',1,'Square']]]
];
