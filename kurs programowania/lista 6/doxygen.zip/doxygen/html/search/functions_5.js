var searchData=
[
  ['setcolor_0',['setColor',['../class_square.html#a4ed244d7719da83ab8bc243ac69eff31',1,'Square']]],
  ['square_1',['Square',['../class_square.html#ae7704882c68fedb0882afdece4ddcfc2',1,'Square']]],
  ['start_2',['start',['../class_program.html#a07e16b0f271def86e0db8ddb012ed5fc',1,'Program']]]
];
