var searchData=
[
  ['isactive_0',['isActive',['../class_square.html#af6c823a9fb643b3ea4c6827251b8b95c',1,'Square']]]
];
