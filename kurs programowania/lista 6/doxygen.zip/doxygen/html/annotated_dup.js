var annotated_dup =
[
    [ "Program", "class_program.html", "class_program" ],
    [ "Square", "class_square.html", "class_square" ],
    [ "Utilities", "class_utilities.html", null ]
];